package utils;

public class MensajesPedidos {
    public static final String PEDIDO_NULO = "El pedido no puede ser nulo.";
    public static final String ERROR_PEDIDO_NO_EXISTE = "El pedido no existe.";
    public static final String ERROR_PEDIDO_YA_EXISTE = "El pedido ya existe.";
}
