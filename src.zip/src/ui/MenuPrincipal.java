package ui;

import java.util.Scanner;
import services.CategoriaServices;
import services.PedidosServices;
import services.ProductoServices;
import services.UsuarioServices;
import utils.UtilsMenu;

public class MenuPrincipal {

    private final Scanner scanner = new Scanner(System.in);
    private final CategoriaServices categoriaServices = new CategoriaServices();
    private final ProductoServices productoServices = new ProductoServices(categoriaServices);
    private final UsuarioServices usuarioServices = new UsuarioServices();
    private final PedidosServices pedidoServices = new PedidosServices(usuarioServices, productoServices);
    private final MenuCategoria menuCategoria;
    private final MenuProducto menuProductos;
    private final MenuUsuarios menuUsuarios;
    private final MenuPedidos menuPedidos;

    public MenuPrincipal() {
        this.menuCategoria = new MenuCategoria(scanner, categoriaServices);
        this.menuProductos = new MenuProducto(scanner, productoServices, categoriaServices);
        this.menuUsuarios = new MenuUsuarios(scanner, usuarioServices);
        this.menuPedidos = new MenuPedidos(scanner, productoServices, usuarioServices, categoriaServices, pedidoServices);
    }

    public void iniciar() {
        boolean salir = false;
        while (!salir) {
            mostrar();
            int opcion = UtilsMenu.leerOpcion(scanner);
            switch (opcion) {
                case 1:
                    menuCategoria.iniciar();
                    break;
                case 2:
                    menuProductos.iniciar();
                    break;
                case 3:
                    menuUsuarios.iniciar();
                    break;
                case 4:
                    menuPedidos.iniciar();
                    break;
                case 0:
                    salir = true;
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opcion no valida. Intente nuevamente.");
            }
        }
    }
    
    public void mostrar() {
        System.out.println("=====================================");
        System.out.println("|| SISTEMA DE PEDIDOS (FOOD STORE) ||");
        System.out.println("=====================================");
        System.out.println("|| 1. Categorias                   ||");
        System.out.println("|| 2. Productos                    ||");
        System.out.println("|| 3. Usuarios                     ||");
        System.out.println("|| 4. Pedidos                      ||");
        System.out.println("|| 0. Salir                        ||");
        System.out.println("=====================================");
        System.out.print("Seleccione una opcion: ");
    }
}
