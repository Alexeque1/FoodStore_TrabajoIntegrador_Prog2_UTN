package services;

import exception.DatoInvalidoException;

import utils.MensajesProducto;

public class ItemPedido {
    private Long idProducto;
    private int cantidad;
    private int stock;
    
    public ItemPedido(Long idProducto, int cantidad) {
        this.idProducto = idProducto;
        this.cantidad = cantidad;
    }
    
    public Long getIdProducto() { 
        return idProducto; 
    }

    public int getCantidad() { 
        return cantidad; 
    }

    public void agregarCantidad(int cantidad) { 
        this.cantidad += cantidad; 
    }

    public void restarStock(int cantidad) {
        if(cantidad > stock) {
            throw new DatoInvalidoException(MensajesProducto.ERROR_SIN_STOCK);
        } else {
            this.stock -= cantidad;
        }
    }
}